<?php

namespace App\Http\Controllers;

use App\Models\Estats_agencies;
use Illuminate\Http\Request;

class EstatsAgenciesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Estats_agencies  $estats_agencies
     * @return \Illuminate\Http\Response
     */
    public function show(Estats_agencies $estats_agencies)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Estats_agencies  $estats_agencies
     * @return \Illuminate\Http\Response
     */
    public function edit(Estats_agencies $estats_agencies)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Estats_agencies  $estats_agencies
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Estats_agencies $estats_agencies)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Estats_agencies  $estats_agencies
     * @return \Illuminate\Http\Response
     */
    public function destroy(Estats_agencies $estats_agencies)
    {
        //
    }
}
