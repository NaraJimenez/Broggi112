<?php

namespace App\Http\Controllers;

use App\Models\Estats_expedients;
use Illuminate\Http\Request;

class EstatsExpedientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Estats_expedients  $estats_expedients
     * @return \Illuminate\Http\Response
     */
    public function show(Estats_expedients $estats_expedients)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Estats_expedients  $estats_expedients
     * @return \Illuminate\Http\Response
     */
    public function edit(Estats_expedients $estats_expedients)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Estats_expedients  $estats_expedients
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Estats_expedients $estats_expedients)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Estats_expedients  $estats_expedients
     * @return \Illuminate\Http\Response
     */
    public function destroy(Estats_expedients $estats_expedients)
    {
        //
    }
}
