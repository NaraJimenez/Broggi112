<?php

namespace App\Http\Controllers;

use App\Models\Cartes_trucades_has_agencies;
use Illuminate\Http\Request;

class CartesTrucadesHasAgenciesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Cartes_trucades_has_agencies  $cartes_trucades_has_agencies
     * @return \Illuminate\Http\Response
     */
    public function show(Cartes_trucades_has_agencies $cartes_trucades_has_agencies)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Cartes_trucades_has_agencies  $cartes_trucades_has_agencies
     * @return \Illuminate\Http\Response
     */
    public function edit(Cartes_trucades_has_agencies $cartes_trucades_has_agencies)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Cartes_trucades_has_agencies  $cartes_trucades_has_agencies
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cartes_trucades_has_agencies $cartes_trucades_has_agencies)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cartes_trucades_has_agencies  $cartes_trucades_has_agencies
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cartes_trucades_has_agencies $cartes_trucades_has_agencies)
    {
        //
    }
}
