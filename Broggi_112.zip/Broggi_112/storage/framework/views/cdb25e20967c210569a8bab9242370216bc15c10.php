<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pagina ejemplo</title>
</head>
<body>
<h1>El usuario es correcto</h1>
</body>
</html>
<?php /**PATH C:\Users\cep.DESKTOP-DE5UDA5\Desktop\xampp\htdocs\Broggi_112\resources\views/prova.blade.php ENDPATH**/ ?>