<?php $__env->startSection('contenido'); ?>
    {
    
    { $user->rol->nombre}
    }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cep.DESKTOP-56UD49B\Desktop\xampp\htdocs\oriol\resources\views/partials/home.blade.php ENDPATH**/ ?>