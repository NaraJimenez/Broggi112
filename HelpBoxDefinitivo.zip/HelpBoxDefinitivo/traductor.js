// Obtener el botón y el pop-up
var button = document.getElementById("myButton");
var popup = document.getElementById("popup");

// Mostrar el pop-up al hacer clic en el botón
button.onclick = function () {
    popup.style.display = "block";
}

// Ocultar el pop-up al hacer clic en el botón de cerrar
var closeButton = document.getElementById("closeButton");
closeButton.onclick = function () {
    popup.style.display = "none";
}



// Idiomas


const languageContainer = document.getElementById("language-container");
// Obtenemos los elementos de la página que necesitamos
const column1Title = document.querySelector('.column h3');
const column1Content = document.querySelectorAll('.column p');
const column2Title = document.querySelectorAll('.column h3')[1];
const column2Content = document.querySelectorAll('.column p')[3];
const column3Title = document.querySelectorAll('.column h3')[2];
const column3Content = document.querySelectorAll('.column p')[6];

// Función para cambiar el idioma
function changeLanguage(lang) {
    switch (lang) {
        case 'es':
            // Actualizamos los textos de la página
            document.getElementById('titulo').innerText = 'Mi Página Web';
            document.getElementById('parrafo').innerText = 'Bienvenidos a mi página web. Aquí encontrarán información sobre mí y mis proyectos.';
            // Actualizamos el valor del atributo 'alt' de las imágenes de idioma
            document.getElementById('primera').alt = 'Español';
            document.getElementById('segunda').alt = 'Catalán';
            document.getElementById('tercera').alt = 'Inglés';
            break;
        case 'ca':
            // Actualizamos los textos de la página
            document.getElementById('titulo').innerText = 'La Meva Pàgina Web';
            document.getElementById('parrafo').innerText = 'Benvinguts a la meva pàgina web. Aquí trobareu informació sobre mi i els meus projectes.';
            // Actualizamos el valor del atributo 'alt' de las imágenes de idioma
            document.getElementById('primera').alt = 'Castellano';
            document.getElementById('segunda').alt = 'Català';
            document.getElementById('tercera').alt = 'Anglès';
            break;
        case 'en':
            // Actualizamos los textos de la página
            document.getElementById('titulo').innerText = 'My Website';
            document.getElementById('parrafo').innerText = 'Welcome to my website. Here you will find information about me and my projects.';
            // Actualizamos el valor del atributo 'alt' de las imágenes de idioma
            document.getElementById('primera').alt = 'Spanish';
            document.getElementById('segunda').alt = 'Catalan';
            document.getElementById('tercera').alt = 'English';
            break;
        default:
            break;
    }
}


// // Agregar evento para cambiar de idioma al hacer clic en la imagen
// const langImgs = document.querySelectorAll('#language-container img');
// langImgs.forEach(function (img) {
//     img.addEventListener('click', function () {
//         const lang = this.getAttribute('alt');
//         changeLanguage(lang);
//     });
// });